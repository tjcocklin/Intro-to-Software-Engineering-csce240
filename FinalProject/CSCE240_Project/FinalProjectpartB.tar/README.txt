Author: Jeffrey Cocklin
Class: CSCE240 setion 2
E-mail: jcocklin@email.sc.edu

Instructions for running simple sequence


Running the progam:

issue the following commands followed by enter to run the program:

make Prog

./a.out <InsertFileToRead> <InsertOutPutFile> <Overlap integer>

*Note: <> represent placeholders for your arguments.


makeFile commands:



Clean: removes a.out object file, and FinalProjectPartB.tar.

*Note: In order for Clean to function a.out and 
FinalProjectPartB.tar must exist.

Prog: constructs the a.out object file.

Tar: creates tar file containing all pertinet files.

Recompile: recompiles a.out object file.



ReportSummary:

Bundled with the files is the ReportSummary file- a report detailing Challenges, 
Revisions, Time complexity,and peer Review for the project as specified by the instructions.
